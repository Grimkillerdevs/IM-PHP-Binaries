#ifndef TSRM_STRTOK_R
#define TSRM_STRTOK_R

#include "TSRM.h"

TSRM_API char *tsrm_strtok_r(char *s, const char *delim, char **last);

#endif
